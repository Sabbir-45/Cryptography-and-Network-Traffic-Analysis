
# Wireshark

- Wireshark হলো একটি Network Protocol Analyzer, Capture, Inspect and Analyze করতে use হয়।
    
- Default Kali তে Wireshark আছে। Discovery section-এ Wireshark আছে।
    
- `eth0` select করে Start দিলে এখানে `eth0` packet pass হয়।
    
- Statistics এ গিয়ে Conversation এ click করলে display open হবে।
    
**Example**
![[Pasted image 20261112230159.png]]


- আমরা দেখতে চাচ্ছি আমাদের IP-এর সাথে কে কে connect করছে। Then:

```bash
ip.addr == 192.168.76.128
```

- Analyze এ যাওয়ার পর Display Filters এ গেলে আমরা নিজেরাই customize করতে পারি।

**Example**
![[Pasted image 20261112231156.png]]

- Coloring করার জন্য Rules জানতে View এ click, then Coloring Rules।
    

### Specific কোনো Port Search

```bash
tcp.port == port_no
udp.port == port_no
```

### কার কার সাথে Source যোগাযোগ করেছে

```bash
ip.src == 192.168.76.128
```

### HTTP Data Capture

```bash
ip.src == 192.168.10.1
```

এখন দেখতে হবে কোথায় কোথায় data আসছে।

- Source: `192.168.10.1`
    
- Destination: `192.168.76.128`
    
- Protocol: HTTP
    

এখানে `192.168.10.1` থেকে আসা response দেখাচ্ছে। কিন্তু password পাঠানোর request সাধারণত Client থেকে Router-এর দিকে যায়।

### 1. সঠিক Filter ব্যবহার করো

প্রথমে এই filter দাও:

```wireshark
ip.addr == 192.168.10.1 && http
```

শুধু Router-এর দিকে যাওয়া HTTP request দেখতে:

```wireshark
ip.dst == 192.168.10.1 && http
```

Login request খুঁজতে:

```wireshark
http.request.method == "POST"
```

যদি router HTTP ব্যবহার করে এবং password plaintext আকারে পাঠায়, তাহলে request body-তে এমন কিছু থাকতে পারে:

```text
username=admin&password=your_password
```

### HTTP POST Request

```http
POST /cgi-bin/luci/ HTTP/1.1
Content-Type: application/x-www-form-urlencoded
Content-Length: 282
```

এর অর্থ:

- `POST` — Router-এ form data পাঠানো হচ্ছে।
    
- `Content-Type` — Form data URL-encoded format-এ পাঠানো হচ্ছে।
    
- `Content-Length: 282` — Request body-এর দৈর্ঘ্য 282 bytes।
    

### Request Body দেখার নিয়ম

1. Packet-এর ওপর Right Click করো।
    
2. Follow → TCP Stream select করো।
    
3. Request body-এর মধ্যে form data দেখতে পারবে।
    

আমার Router-এর captured data:

```text
luci_username=admin
luci_password=fe6aca16703fc34d44bd17e5cd49c621b6ce1841529ace9501cadba34adb3efc
```

**Screenshot**
![[Pasted image 20261113004117.png]]



## TShark – Complete Basic Commands

TShark হলো Wireshark-এর command-line version। এটি terminal ব্যবহার করে network traffic capture ও analyze করতে সাহায্য করে।

### 1. Network Interface দেখা

```
tshark -D
```

কাজ: Computer-এর available network interfaces-এর list দেখায়।

### 2. Ethernet Traffic Capture

```
sudo tshark -i eth0
```

কাজ: `eth0` Ethernet interface দিয়ে network traffic capture করে।

### 3. Wi-Fi Traffic Capture

```
sudo tshark -i wlan0
```

কাজ: `wlan0` Wi-Fi interface দিয়ে network traffic capture করে।

### 4. নির্দিষ্ট সংখ্যক Packet Capture

```
sudo tshark -i eth0 -c 50
```

কাজ: মোট ৫০টি packet capture করার পর বন্ধ হবে।

### 5. নির্দিষ্ট Host-এর Traffic Capture

```
sudo tshark -i eth0 -f "host 192.168.76.128"
```

কাজ: নির্দিষ্ট IP address-এর traffic capture করে।

### 6. নির্দিষ্ট Port-এর Traffic Capture

```
sudo tshark -i eth0 -f "port 80"
```

কাজ: Port 80-এর traffic capture করে।

### 7. HTTP Traffic Capture

```
sudo tshark -i eth0 -f "tcp port 80"
```

কাজ: HTTP-এর সাধারণ TCP port 80-এর traffic capture করে।

### 8. DNS Traffic Capture

```
sudo tshark -i eth0 -f "udp port 53"
```

কাজ: DNS-এর UDP port 53-এর traffic capture করে।

### 9. Packet Capture করে File-এ Save

```
sudo tshark -i eth0 -w capture.pcap
```

কাজ: Captured packets `capture.pcap` ফাইলে save করে।

### 10. Saved Capture File Read

```
tshark -r capture.pcap
```

কাজ: আগে save করা PCAP file থেকে packet information দেখায়।

### 11. Display Filter ব্যবহার

```
tshark -r capture.pcap -Y "http"
```

কাজ: Capture file থেকে শুধু HTTP packets দেখায়।

### 12. নির্দিষ্ট IP-এর Packet Filter

```
tshark -r capture.pcap -Y "ip.addr == 192.168.76.128"
```

কাজ: নির্দিষ্ট IP address-এর সঙ্গে সম্পর্কিত packets দেখায়।

### 13. শুধু DNS Packet দেখা

```
tshark -r capture.pcap -Y "dns"
```

কাজ: Capture file থেকে শুধু DNS packets দেখায়।

### 14. Packet Capture বন্ধ করা

Terminal-এ:

```
Ctrl + C
```

কাজ: চলমান packet capturing বন্ধ করে।

## Important Options

|Option|কাজ|
|---|---|
|`-D`|Available interfaces দেখায়|
|`-i`|Interface select করে|
|`-c`|নির্দিষ্ট সংখ্যক packet capture করে|
|`-f`|Capture filter ব্যবহার করে|
|`-Y`|Display filter ব্যবহার করে|
|`-w`|Capture file-এ save করে|
|`-r`|Saved capture file read করে|
|`-V`|Detailed packet information দেখায়|
|`-h`|Help information দেখায়|

## Capture Filter vs Display Filter

|Capture Filter (`-f`)|Display Filter (`-Y`)|
|---|---|
|Capture করার সময় filter করে|Capture হওয়ার পরে display filter করে|
|`-f "port 80"`|`-Y "http"`|
|Capture file-এ শুধু matching packets রাখে|File-এর matching packets শুধু দেখায়|
