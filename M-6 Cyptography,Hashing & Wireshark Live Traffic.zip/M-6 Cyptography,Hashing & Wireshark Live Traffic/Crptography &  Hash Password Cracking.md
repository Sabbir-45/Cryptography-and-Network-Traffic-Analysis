
# Cipher Text Encryption Rule

**Encryption:** সামনের দিকে (Forward) যেতে হবে।

**Decryption:** পেছনের দিকে (Backward) যেতে হবে।

```text
A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
```

**Plain Text:** sabbir

**PIN:** 2

**Cipher Text:** UCDDKT

এই Cipher Text থেকে Plain Text বের করতে Backward করতে হবে।

---

# AES

(Modern Web Application-এ AES ব্যবহার করা হয়।)

- Block Size: 128 bit
    
- Key Size: 128, 192, 256 bit
    

**AES-128:** 128-bit key

**AES-192:** 192-bit key

**AES-256:** 256-bit key

---

# DES

Full Form: Data Encryption Standard

- Key Length: 56 bits
    
- Block Size: 64 bits
    
- এটি Modern Use-এর জন্য Insecure।
    

---

# Asymmetric Cryptography

এখানে ২টি Key থাকে:

1. Public Key
    
2. Private Key
    

- Public Key সবার সঙ্গে Share করা যায়।
    
- Private Key শুধু Owner-এর কাছে থাকে।
    
- Digital Signature-এর কাজে ব্যবহার করা হয়।
    

**Example:** Public Key এবং Private Key মূলত আলাদা Key। Public Key থেকে Private Key বের করা practically অসম্ভব।

![[Pasted image 20261112215806.png|285]]

---

# Cryptography Hashing

Input Data-এর Length যত বড় বা ছোট হোক, Hashing সেটিকে Fixed Length-এ Convert করে।

Terminal-এ `Nakib`-কে `sha256sum` দিয়ে Hashing করলাম।

প্রতিবার Space বা অন্য কোনো Character পরিবর্তন করলে Hash পরিবর্তন হয়ে যায়।

**Input:** Nakib

**Hash Length:** 64 Characters

**Example:**
![[Pasted image 20261112110353.png|464]]

তারপর Save করতে চাইলে Hash-টি এই Format-এ দিতে হবে।
![[Pasted image 20261112203648.png]]
### Common Hash Algorithms

- MD5 – 128 bit
    
- SHA-1 – 160 bit
    
- SHA-256 – 256 bit
    
- SHA-512 – 512 bit
    
- SHA-3
    

Same Password দিলে Same Hash পাওয়া যায়। কিন্তু Unique Salt ব্যবহার করলে Random Salt যুক্ত হয় এবং Different Stored Hash তৈরি হয়। Password Verify করার সময় Salt ব্যবহার করে Hash Compare করা যায়।


# Hash Crack

প্রথমে Website-এ Hash Generator-এ যাব।

**Website:** [https://coddy.tech/tools/hash-generator](https://coddy.tech/tools/hash-generator)

**Input:** 123456

### Database

|Username|Password Hash|
|---|---|
|Nakib|8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92|

---

# Tool: Hashcat

Hashcat Kali Linux-এ Install করা থাকে। এটি একটি Password Recovery Tool।

**1. Help দেখার জন্য:**

```bash
hashcat --help
```

Directory লাগে Perform করার জন্য, যেখানে প্রয়োজনীয় File পাওয়া যাবে।

যদি Wordlists Delete হয়ে যায়:

```bash
sudo apt reinstall wordlists
```

**2. Directory-তে যাওয়ার জন্য:**

```bash
cd /usr/share/wordlists
```

**3. File দেখার জন্য:**

```bash
ls
```

তখন `rockyou.txt.gz` পাওয়া যাবে।

**4. Extract করার জন্য:**

```bash
sudo gunzip rockyou.txt.gz
```

**5. আবার File দেখার জন্য:**

```bash
ls
```

**6. Wordlist-এ কতগুলো Password আছে দেখার জন্য:**

```bash
wc -l rockyou.txt
```

**Weakpass** থেকে Password Wordlist Download করা যায়। এগুলো ZIP Format-এ পাওয়া যায়।

**7. Extended Help:**

```bash
hashcat -hh
```

এখানে Hash কোন Format-এ করা হয়েছে, তা Search করতে হবে। যেমন: `sha2-256`।

**8. Hash Format Identify করার জন্য:**

```bash
hashid 8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92
```

Another Method:

```bash
hash-identifier 8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92
```

**Website দিয়ে Check করতে:**

[https://crackstation.net/](https://crackstation.net/)

**9. Hashcat দিয়ে Hash Crack:**

প্রথমে `/usr/share/wordlists` Directory-তে গিয়ে:

```bash
hashcat -m 1400 8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92 rockyou.txt
```

**10. আগে Crack করা Password Show করার জন্য:**

```bash
hashcat -m 1400 8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92 --show
```

- Connection Break বা Special Character-এর সমস্যা হলে Single বা Double Quotation ব্যবহার করতে হবে।
- Hash ID Check করার সময় এই ধরনের সমস্যা হতে পারে।
![[Pasted image 20261112204027.png]]



# Another Tool: John the Ripper

Password Crack করার আরেকটি Tool হলো John the Ripper।

**1. Help দেখার জন্য:**

```bash
john -h
```

### Password

Hash on bcrypt Format:

```text
$2a$12$xVTZi5y1gy6Tpk6RiltnPeXT4L6.7F3VdEk.mDluww8muqmTPgmCi
```

**2. John চালানোর জন্য আগে Hash Save করতে হবে।**

```bash
echo '$2a$12$xVTZi5y1gy6Tpk6RiltnPeXT4L6.7F3VdEk.mDluww8muqmTPgmCi' | sudo tee hash.txt
```

`sudo tee` হলো Linux-এর একটি Command, যা Root Permission ব্যবহার করে কোনো Text বা Data File-এর মধ্যে লিখতে সাহায্য করে।

Format-এর মধ্যে Hash কোন Format-এ আছে, তা নির্ধারণ করতে হবে। এখানে `=`-এর পরে Hash Format দিতে হবে।

**আমি** `**/usr/share/wordlists**` **Folder-এ আছি।**

**3. John দিয়ে Hash Crack:**

```bash
john --format=bcrypt --wordlist=rockyou.txt hash.txt
```

অথবা:

```bash
john --format=Raw-SHA512 --wordlist=rockyou.txt 2ndhash.txt
```

অথবা:

```bash
john --format=bcrypt --wordlist=/usr/share/wordlists/rockyou.txt hash.txt
```

**4. Cracked Password দেখার জন্য:**

```bash
john hash.txt --show
```


অথবা:

```bash
john --show --format=Raw-SHA512 3hash.txt                                     

```
## Wordlist পাওয়া যাবে

- **Weakpass** থেকে Wordlist download করা যায়।
    
- **SecLists** (Kali Linux-এ পাওয়া যায়): [https://github.com/danielmiessler/seclists](https://github.com/danielmiessler/seclists)
    

### 1. SecLists Install করার জন্য

```
sudo apt install seclists
```

### 2. SecLists ব্যবহার

প্রথমে SecLists-এর directory ও file দেখতে:

```
ls
```

Passwords folder-এ প্রবেশ করতে:

```
cd Passwords
```

তারপর folder-এর ভেতরের Wordlist দেখতে:

```
ls
```





